/*===========================================================
  Script C (Azure SQL): Change Round 2 (optional)
  Creates additional versions for richer SCD2 history
===========================================================*/

WAITFOR DELAY '00:00:02';
GO

-- Customer moves again (NY -> IL)
UPDATE dbo.DimCustomer
SET City = N'Chicago',
    StateProvince = N'IL',
    PostalCode = N'60601'
WHERE CustomerAltID = N'C-1001';
GO

WAITFOR DELAY '00:00:02';
GO

-- Suspended customer returns to Active + segment change
UPDATE dbo.DimCustomer
SET Status = N'Active',
    CustomerSegment = N'Enterprise',
    CreditLimit = 50000.00
WHERE CustomerAltID = N'C-1003';
GO