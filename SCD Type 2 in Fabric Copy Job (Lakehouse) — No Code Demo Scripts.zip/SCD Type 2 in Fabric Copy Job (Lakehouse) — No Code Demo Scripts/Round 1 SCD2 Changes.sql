/*===========================================================
  Script B (Azure SQL): Change Round 1
  Generates updates + insert + delete for CDC/SCD2 demo
===========================================================*/

WAITFOR DELAY '00:00:02';
GO

------------------------------------------------------------
-- 1) Classic SCD2 example: customer moves (CA -> NY)
------------------------------------------------------------
UPDATE dbo.DimCustomer
SET City = N'New York',
    StateProvince = N'NY',
    PostalCode = N'10001'
WHERE CustomerAltID = N'C-1001';
GO

WAITFOR DELAY '00:00:02';
GO

------------------------------------------------------------
-- 2) Upgrade: segment + credit limit change
------------------------------------------------------------
UPDATE dbo.DimCustomer
SET CustomerSegment = N'VIP',
    CreditLimit = 150000.00
WHERE CustomerAltID = N'C-1002';
GO

WAITFOR DELAY '00:00:02';
GO

------------------------------------------------------------
-- 3) Status change: Active -> Suspended
------------------------------------------------------------
UPDATE dbo.DimCustomer
SET Status = N'Suspended'
WHERE CustomerAltID = N'C-1003';
GO

WAITFOR DELAY '00:00:02';
GO

------------------------------------------------------------
-- 4) Insert: new customer
------------------------------------------------------------
INSERT INTO dbo.DimCustomer
(
    CustomerAltID, CustomerName, Email, Phone,
    City, StateProvince, Country, PostalCode,
    CustomerSegment, Status, CreditLimit
)
VALUES
(N'C-1006', N'Tailspin Toys', N'sales@tailspin.com', N'555-0106',
 N'Boston', N'MA', N'USA', N'02108', N'SMB', N'Active', 30000.00);
GO

WAITFOR DELAY '00:00:02';
GO

------------------------------------------------------------
-- 5) Delete: customer removed from source (soft delete demo)
------------------------------------------------------------
DELETE FROM dbo.DimCustomer
WHERE CustomerAltID = N'C-1004';
GO

SELECT * FROM dbo.DimCustomer ORDER BY CustomerAltID;