/*===========================================================
  Script A (Azure SQL): Create + seed dbo.DimCustomer
  - NO CustomerID column
  - CustomerAltID is the Business Key (Primary Key)
  - No Created/Modified timestamps
===========================================================*/

IF OBJECT_ID('dbo.DimCustomer', 'U') IS NOT NULL
    DROP TABLE dbo.DimCustomer;
GO

CREATE TABLE dbo.DimCustomer
(
    CustomerAltID     NVARCHAR(20)   NOT NULL,   -- business key
    CustomerName      NVARCHAR(100)  NOT NULL,
    Email             NVARCHAR(200)  NULL,
    Phone             NVARCHAR(30)   NULL,
    City              NVARCHAR(60)   NULL,
    StateProvince     NVARCHAR(60)   NULL,
    Country           NVARCHAR(60)   NULL,
    PostalCode        NVARCHAR(20)   NULL,
    CustomerSegment   NVARCHAR(30)   NULL,       -- SMB / Enterprise / VIP
    Status            NVARCHAR(20)   NOT NULL,   -- Active / Suspended
    CreditLimit       DECIMAL(12,2)  NULL,

    CONSTRAINT PK_DimCustomer PRIMARY KEY CLUSTERED (CustomerAltID)
);
GO

INSERT INTO dbo.DimCustomer
(
    CustomerAltID, CustomerName, Email, Phone,
    City, StateProvince, Country, PostalCode,
    CustomerSegment, Status, CreditLimit
)
VALUES
(N'C-1001', N'Acme Corp',          N'contact@acme.com',     N'555-0101', N'San Diego', N'CA', N'USA', N'92101', N'SMB',        N'Active',    25000.00),
(N'C-1002', N'Northwind Traders',  N'hello@northwind.com',  N'555-0102', N'Dallas',    N'TX', N'USA', N'75201', N'Enterprise', N'Active',    90000.00),
(N'C-1003', N'Contoso Retail',     N'info@contoso.com',     N'555-0103', N'Orlando',   N'FL', N'USA', N'32801', N'SMB',        N'Active',    15000.00),
(N'C-1004', N'Fabrikam Logistics', N'support@fabrikam.com', N'555-0104', N'Seattle',   N'WA', N'USA', N'98101', N'Enterprise', N'Active',   120000.00),
(N'C-1005', N'Globex Corporation', N'ops@globex.com',       N'555-0105', N'Phoenix',   N'AZ', N'USA', N'85001', N'VIP',        N'Active',   200000.00);
GO

SELECT * FROM dbo.DimCustomer ORDER BY CustomerAltID;
