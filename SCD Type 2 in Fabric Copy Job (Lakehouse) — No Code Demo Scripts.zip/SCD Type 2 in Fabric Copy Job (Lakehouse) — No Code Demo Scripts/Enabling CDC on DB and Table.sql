-- Enable CDC at the database level (run once per database)
IF (SELECT is_cdc_enabled FROM sys.databases WHERE name = DB_NAME()) = 0
BEGIN
    EXEC sys.sp_cdc_enable_db;
END
GO

-- Enable CDC for the table (run once per table)
IF NOT EXISTS (SELECT 1 FROM cdc.change_tables WHERE source_object_id = OBJECT_ID('dbo.DimCustomer'))
BEGIN
    EXEC sys.sp_cdc_enable_table
        @source_schema = N'dbo',
        @source_name   = N'DimCustomer',
        @role_name     = NULL;  -- or specify a role for CDC access
END
GO